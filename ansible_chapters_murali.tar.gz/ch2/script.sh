
a=5
echo $a
