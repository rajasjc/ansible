#!/bin/bash
#creating a for loop
for i in {1..10}
do
echo "Welcome to Redhat Ansible Training"
sleep 1
done

